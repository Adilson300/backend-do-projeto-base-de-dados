const express = require("express");
const app = express();

const handlebars = require('express-handlebars')
const Sequelize = require('sequelize')


//Configurar
    //Template Engine
    app.engine('handlebars', handlebars({defaultLayout: 'index'}))
    app.set('view engine' , 'handlebars')

//Conexão com a base de dados
const sequelize = new Sequelize('dblaridoso', 'root','Juma.org.123#$%', {
    host:"localhost",
    dialect:'mysql'

})

app.get ('/cad', function(req,res){
    res.render('idoso')
})





app.listen(8081, function(){
    console.log("Servidor Rodando na url http://localhost:8081");
});